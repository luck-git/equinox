import os
import pickle
import gradio as gr
from langchain.llms import OpenAI
from langchain.chat_models import ChatOpenAI
from langchain.embeddings.openai import OpenAIEmbeddings
#from langchain.chains import load_qa_chain, RetrievalQA
from langchain.chains.question_answering import load_qa_chain
from langchain.vectorstores import FAISS
from langchain.document_loaders import TextLoader
import openai
import gradio as gr

# Set your OpenAI API key
os.environ["OPENAI_API_KEY"] = "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"
openai.api_key = "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"

# Initialize OpenAI chat model
openai = ChatOpenAI(model_name="gpt-3.5-turbo", temperature=1, max_tokens=3000)

# Load QA chain
chain = load_qa_chain(openai, chain_type="stuff")

# Load FAISS index and embeddings
embeddings = OpenAIEmbeddings()
new_db = FAISS.load_local("faiss_index_equinox_data_1", embeddings)

# Function to interact with the chatbot
def chatbot(query):
    prompt = query
    docs = new_db.similarity_search(query)
    response = chain.run(input_documents=docs, question=prompt)
    return response

# Gradio interface setup
text_input = gr.inputs.Textbox(label="Type your question here")
output_text = gr.outputs.Textbox(label="AI-generated response")

title_html = "<h2 style='text-align:center;font-weight:bold;color:black;'> Magnawave </h2>"
desc_html = "<p style='text-align:center;'>Get instant responses to any question related to Magnawave by asking our AI chatbot.</p>"

chatbot_interface = gr.Interface(
    fn=chatbot,
    inputs=text_input,
    outputs=output_text,
    title=title_html,
    description=desc_html,
    allow_screenshot=False
)

# Launch the Gradio interface
chatbot_interface.launch(share=True)